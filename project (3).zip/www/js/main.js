let map = L.map('map').setView([34.647861815440706, 135.04510482313825], 11);
/*
L.tileLayer('https://cyberjapandata.gsi.go.jp/xyz/std/{z}/{x}/{y}.png', {
  attribution: "<a href='https://maps.gsi.go.jp/development/ichiran.html' target='_blank'>地理院タイル</a>"
}).addTo(map);
*/
L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
}).addTo(map);

L.marker([34.6288553938514, 135.04355963379842]).addTo(map)
    .bindPopup('兵庫県神戸市垂水区五色山六丁目2-408')
L.marker([34.62950094850132, 135.04328295384963]).addTo(map)
    .bindPopup('兵庫県神戸市垂水区五色山六丁目6-1-108号室')
L.marker([34.629096159513615, 135.04885605946248]).addTo(map)
    .bindPopup('兵庫県神戸市垂水区五色山二丁目2-37')
L.marker([34.63078314301288, 135.04792236124652]).addTo(map)
    .bindPopup('兵庫県神戸市垂水区五色山三丁目2-30')
L.marker([34.64003288129364, 135.03557619858896]).addTo(map)
    .bindPopup('兵庫県神戸市垂水区舞子台七丁目1-2')
L.marker([34.64022850531156, 135.03558953915268]).addTo(map)
    .bindPopup('兵庫県神戸市垂水区舞子台七丁目1-1')
L.marker([34.64135613848176, 135.05364108148012]).addTo(map)
    .bindPopup('兵庫県神戸市垂水区上高丸一丁目6-33')
L.marker([34.64650342303158, 135.00267367003627]).addTo(map)
    .bindPopup('')
L.marker([34.679294678666565, 135.05605252566286]).addTo(map)
    .bindPopup('')
L.marker([34.680665111628755, 135.0573810916063]).addTo(map)
    .bindPopup('')
L.marker([34.64628934221859, 135.07626999652908]).addTo(map)
    .bindPopup('')
L.marker([34.631687096374385, 135.06906156798868]).addTo(map)
    .bindPopup('')
L.marker([34.63597607638165, 135.0726701913025]).addTo(map)
    .bindPopup('')
L.marker([34.64458393561663, 135.1151376151295]).addTo(map)
    .bindPopup('')
L.marker([34.65674210029401, 135.08067873915343]).addTo(map)
    .bindPopup('兵庫県神戸市垂水区桃山台三丁目13-4')